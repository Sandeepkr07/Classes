const player = new Plyr('#player');

function playCustomUrl() {
  const url = document.getElementById('customUrl').value;
  if (url.trim()) {
    player.source = {
      type: 'video',
      sources: [{ src: url, provider: 'html5' }]
    };
    player.play();
  }
}

function playVideo(encodedUrl) {
  try {
    const url = atob(encodedUrl);
    player.source = {
      type: 'video',
      sources: [{ src: url, provider: 'html5' }]
    };
    player.play();
  } catch {
    player.source = {
      type: 'video',
      sources: [{ src: encodedUrl, provider: 'html5' }]
    };
    player.play();
  }
}

function toggleTheme() {
  const root = document.documentElement;
  const isDark = root.getAttribute('data-theme') === 'dark';
  root.setAttribute('data-theme', isDark ? 'light' : 'dark');
  document.querySelector('.fa-sun').style.display = isDark ? 'none' : 'inline';
  document.querySelector('.fa-moon').style.display = isDark ? 'inline' : 'none';
}
